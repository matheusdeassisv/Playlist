require('dotenv').config();
const express = require('express');
const path = require('path');
const connectToDatabase = require('./database/db');
const Music = require('./model/Music');

//chaando o app

const app = express();

//definindo a porta
const port = process.env.PORT || 5000;

let music = null; //quando renderizar a página, a variável vem como nula às músicas
let musicDel = null;

//inicializando

app.set("view engine", "ejs"); //renderizando o ejs


//conectando com o mongo db

connectToDatabase();
app.use(express.static(path.join(__dirname,"public"))); // ligando o diretório
app.use(express.urlencoded()) //lendo o diretório

//criando um index onde eu vou renderizar a playlist

app.get("/", async (req,res) => {
    const playlist = await Music.find();
    console.log(playlist); // apenas para mostrar no console
    res.render("index", {playlist}); //renderizando a playlist 
});

//renderizando a pagina admin com as informações

app.get("/admin", async (req,res) => {
    const playlist = await Music.find();
    res.render("admin",{ playlist, music: null, musicDel: null}); //renderizando o admin
});


//criando a playlist

app.post("/create", async (req,res) => {
    const music = req.body; // enviando as informações para o banco
    await Music.create(music); //gravando as informações no banco de dados
    res.redirect("/"); //retornando para a página inicial
});


//editando as informações da música com o app.get

app.get("/by/:id/:actions", async (req,res) => {
    const { id, actions } = req.params;
    music = await Music.findById({_id: id});
    const playlist = await Music.find();

    if(actions == "edit"){
        res.render("admin", {playlist, music, musicDel:null }); //renderizando a playlist e a música editada
    }else{
        res.render("admin", {playlist, music: null, musicDel: music}); //renderizando a playlist e a música editada
    } 
});


//atualizando as informações da música com o app.post

app.post("/update/:id", async (req,res) => {
    const newMusic = req.body; // enviando as informações para o banco

    await Music.updateOne({_id:req.params.id}, newMusic); //atualizando no banco
    
    res.redirect("/admin"); //atualizando a playlist e voltando pra página

});

//deletando uma música

app.get("/delete/:id", async (req,res) => {
    await Music.deleteOne({_id:req.params.id});
    res.redirect("/admin"); //deletando a musica e voltando para a página
});


//passando a porta do servidor

app.listen(port, () => console.log(`Servidor rodando em http://localhost:${port}`));