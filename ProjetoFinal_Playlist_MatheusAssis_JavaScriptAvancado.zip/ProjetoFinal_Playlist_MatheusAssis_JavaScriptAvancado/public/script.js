//lógica: determinar aonde está clicando e o tipo da tarefa

const controls = document.querySelector("#controls"); //referindo ao id

const btnPlay = document.querySelector("#play-control"); //não esquecer a # pra identificar o id do html

let index = 0; //primeira musica do player

let currentMusic; //musica atual

let isPlaying = false; //padrao incial

controls.addEventListener("click", function (event) {
  //console.log(events);
  const audios = []; //teremos várias músicas, vamos pegar através das linhas do html
  let music = {};
  //console.log(events);
  //const musics = event.path[2].childNodes[3].childNodes[5].childNodes[1].childNodes; //os números representam a posição nos quais os elementos sao identificados no html

  //o path[2] é o body do html

  //console.log(musics);

  if (event.target.id != "controls") {
    //evento do clique
    const nodeList = document.body.childNodes;
    console.log(nodeList);
    const musics = nodeList[3].childNodes[5].childNodes[1].childNodes[3].childNodes;
    console.log(musics);
    musics.forEach(function (item) {
      if (item.nodeName != "#text") {//a condição é se for diferente de #text é #td
        music.name = item.childNodes[3].childNodes[0].data; // identificando o nome da música sendo tocada
        music.artist = item.childNodes[5].childNodes[0].data; // identificando o nome do artista da música sendo tocada
        music.image = item.childNodes[1].childNodes[0].currentSrc; // identificando a imagem da música sendo tocada
        music.audio = item.childNodes[7].childNodes[1]; //identificando o àudio da musica
        audios.push(music); //passando a música
        music = {};
      }
    });
    console.log(audios);
  } //fechamento do if

  function updateDataMusic() {
    //função para identificar a música que está tocando, e passar para a próxima musica quando acabar

    currentMusic = audios[index]; //parametro para identificar a música atual

    //identificar cada id com o querySelector

    document.querySelector("#currentImg").src = currentMusic.image;
    document.querySelector("#currentName").innerText = currentMusic.name;
    document.querySelector("#currentArtist").innerText = currentMusic.artist;
    document.querySelector("#volume").value = currentMusic.audio.volume * 100; //colocando o volume para atingir até 100%

    //progressão da barra e da música

    const progressbar = document.querySelector("#progressbar");
    const txtCurrentDuration = document.querySelector("#current-duration");
    const txtTotalDuration = document.querySelector("#total-duration");

    //pegar a progressbar e armazenar

    progressbar.max = currentMusic.audio.duration;
    txtTotalDuration.innerText = secondsToMinutes(currentMusic.audio.duration);

    currentMusic.audio.ontimeupdate = function () {
      txtCurrentDuration.innerText = secondsToMinutes(
        currentMusic.audio.currentTime
      );
      progressbar.valueAsNumber = currentMusic.audio.currentTime;
    };

    // updateDataMusic();
  }
  if (event.target.id == "play-control") {
    if (index === 0) {
      updateDataMusic();
    }
    if (!isPlaying) {
      btnPlay.classList.replace("bi-play-fill", "bi-pause-fill");
      currentMusic.audio.play();
      isPlaying = true;
    } else {
      btnPlay.classList.replace("bi-pause-fill", "bi-play-fill");
      currentMusic.audio.pause();
      isPlaying = false;

      //não está tocando
    }
    musicEnded();
  }
  if (event.target.id == "vol-icon") {
    currentMusic.audio.muted = !currentMusic.audio.muted;
    if (currentMusic.audio.muted) {
      event.target.classList.replace(
        "bi-volume-up-fill",
        "bi-volume-mute-fill"
      );
    } else {
      event.target.classList.replace(
        "bi-volume-mute-fill",
        "bi-volume-up-fill"
      );
    }
    musicEnded();
  }
  if (event.target.id == "volume") {
    currentMusic.audio.volume = event.target.valueAsNumber / 100;
    musicEnded();
  }
  if (event.target.id == "progressbar") {
    currentMusic.audio.currentTime = event.target.valueAsNumber;
    musicEnded();
  }
  if (event.target.id == "next-control") {
    index++;
    if (index == audios.length) {
      index = 0;
    }
    currentMusic.audio.pause();
    updateDataMusic();
    currentMusic.audio.play();
    btnPlay.classList.replace("bi-play-fill", "bi-pause-fill");
    musicEnded();
  }
  if (event.target.id == "prev-control") {
    index--;
    if (index == -1) {
      index = audios.length - 1;
    }
    currentMusic.audio.pause();
    updateDataMusic();
    currentMusic.audio.play();
    btnPlay.classList.replace("bi-play-fill", "bi-pause-fill");
    musicEnded();
  }
  function musicEnded() {
    currentMusic.audio.addEventListener("ended", function () {
      index++;
      if (index == audios.length) {
        index = 0;
      }
      currentMusic.audio.pause();
      updateDataMusic();
      currentMusic.audio.play();
      btnPlay.classList.replace("bi-play-fill", "bi-pause-fill");
    });
  }
});

function secondsToMinutes(time) {
  const minutes = Math.floor(time / 60);
  const seconds = Math.floor(time % 60);
  return `${("0" + minutes).slice(-2)} :  ${("0" + seconds).slice(-2)}`; //tirando as 2 casas decimais
}
