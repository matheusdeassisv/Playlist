const mongodb = require('mongoose'); 
mongodb.set("strictQuery", true);
 const connectToDatabase = async () => { 
    //mongodb+srv://assisvieira99:MatheusDeAssisVieira@clusterplaylist.awfvqe3.mongodb.net/?retryWrites=true&w=majority

  await mongodb.connect(process.env.DB_URI, { 
        useNewUrlParser: true, 
        useUnifiedTopology: true,
    }).then(() => console.log('Mongo DB Conectato!')).catch((error) => console.error(error));
};


module.exports = connectToDatabase;